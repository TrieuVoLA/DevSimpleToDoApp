package com.autonsi.devsimpletodoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.widget.EditText;

import com.autonsi.devsimpletodoapp.model.ToDoItem;
import com.autonsi.devsimpletodoapp.viewmodels.ToDoViewModel;
import android.os.Bundle;
import android.view.View;

import androidx.lifecycle.ViewModelProvider;
public class AddEditActivity extends AppCompatActivity {
    private ToDoViewModel viewModel;
    private EditText taskNameEditText;
    private ToDoItem task;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit);

        taskNameEditText = findViewById(R.id.task_name_edit_text);
        viewModel = new ViewModelProvider(this).get(ToDoViewModel.class);

        task = (ToDoItem) getIntent().getParcelableExtra("task");

        if (task != null) {
            taskNameEditText.setText(task.getTaskName());
        }

        findViewById(R.id.save_button).setOnClickListener(v -> {
            String taskName = taskNameEditText.getText().toString();
            if (task != null) {
                task.setTaskName(taskName);
                viewModel.updateToDoItem(task.getId(), task, null);
            } else {
                ToDoItem newTask = new ToDoItem(11,201 , taskName, 0);
                viewModel.addToDoItem(newTask, null);
            }
            finish();
        });
    }

}