package com.autonsi.devsimpletodoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.os.Parcelable;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.autonsi.devsimpletodoapp.adapter.ToDoAdapter;
import com.autonsi.devsimpletodoapp.model.ToDoItem;
import com.autonsi.devsimpletodoapp.repository.ToDoRepository;
import com.autonsi.devsimpletodoapp.viewmodels.ToDoViewModel;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE = 23;
    public ToDoViewModel viewModel;
    private ToDoAdapter adapter;
    private List<ToDoItem> toDoItemList = new ArrayList<>();
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        viewModel = new ViewModelProvider(this).get(ToDoViewModel.class);

//        viewModel.getToDoList().observe(this, toDoItems -> {
//            adapter = new ToDoAdapter(toDoItems, new ToDoAdapter.OnItemClickListener() {
//                @Override
//                public void onEditClick(ToDoItem item) {
//                    Intent intent = new Intent(MainActivity.this, AddEditActivity.class);
//                    intent.putExtra("task", (Parcelable) item);
//                    startActivity(intent);
//                }
//
//                @Override
//                public void onDeleteClick(ToDoItem item) {
//                    viewModel.deleteToDoItem(item.getId(), null);
//                }
//            });
//            recyclerView.setAdapter(adapter);
//        });

        viewModel.getToDoList().observe(this, new Observer<List<ToDoItem>>() {
            @Override
            public void onChanged(List<ToDoItem> toDoItems) {
                toDoItemList = toDoItems;
                setupRecyclerView();
            }
        });

        findViewById(R.id.add_task_button).setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddEditActivity.class);
            startActivity(intent);
        });
    }

    private void setupRecyclerView()
    {
        if(adapter == null) {
            adapter = new ToDoAdapter(toDoItemList, new ToDoAdapter.OnItemClickListener() {
                @Override
                public void onEditClick(ToDoItem item) {
                    Intent intent = new Intent(MainActivity.this, AddEditActivity.class);
                    intent.putExtra("task", (Parcelable) item);
                    startActivityForResult(intent,REQUEST_CODE);
                }

                @Override
                public void onDeleteClick(ToDoItem item) {
                    viewModel.deleteToDoItem(item.getId(), null);
                }
            });
            recyclerView.setAdapter(adapter);
        } else {
            adapter.notifyDataSetChanged();
        }
    }

//
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            // Nhận dữ liệu từ AddEditActivity và cập nhật LiveData
            //Item updatedItem = data.getParcelableExtra("updatedTask");
            adapter.notifyDataSetChanged(); // Cập nhật item
        }
    }

}