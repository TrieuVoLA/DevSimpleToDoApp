package com.autonsi.devsimpletodoapp.viewmodels;



import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.autonsi.devsimpletodoapp.RetrofitClient;
import com.autonsi.devsimpletodoapp.model.ToDoItem;
import com.autonsi.devsimpletodoapp.repository.ToDoRepository;

import java.util.List;

import retrofit2.Callback;

public class ToDoViewModel extends ViewModel {
    private ToDoRepository repository  ;
    public MutableLiveData<List<ToDoItem>> todoList = new MutableLiveData<>() ;
    //private final MutableLiveData<List<ToDoItem>> toDoListLiveData = new MutableLiveData<>();

    public ToDoViewModel() {
        this.repository = new ToDoRepository();
        /*this.todoList =*/ repository.getToDoList();
    }

    public LiveData<List<ToDoItem>> getToDoList() {
        return todoList;
    }
//    public void setTodoList(MutableLiveData<List<ToDoItem>> todoList) {
//        this.todoList = todoList;
//    }

    public void addToDoItem(ToDoItem newTask, Callback<ToDoItem> callback) {
        repository.addToDoItem(newTask, callback);
    }

    public void updateToDoItem(int id, ToDoItem updatedTask, Callback<ToDoItem> callback) {
        repository.updateToDoItem(id, updatedTask, callback);
    }

    public void deleteToDoItem(int id, Callback<Void> callback) {
        repository.deleteToDoItem(id, callback);
    }
}

