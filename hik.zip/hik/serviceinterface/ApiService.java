package com.autonsi.devsimpletodoapp.serviceinterface;

import com.autonsi.devsimpletodoapp.model.ToDoItem;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

import java.util.List;

public interface ApiService {
    @GET("todos")
    Call<List<ToDoItem>> getToDoList();

    @POST("todos")
    Call<ToDoItem> addToDoItem(@Body ToDoItem newTask);

    @PUT("todos/{id}")
    Call<ToDoItem> updateToDoItem(@Path("id") int id, @Body ToDoItem updatedTask);

    @DELETE("todos/{id}")
    Call<Void> deleteToDoItem(@Path("id") int id);
}

