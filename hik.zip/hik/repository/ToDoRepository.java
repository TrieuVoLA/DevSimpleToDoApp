package com.autonsi.devsimpletodoapp.repository;

import android.util.Log;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.autonsi.devsimpletodoapp.MainActivity;
import com.autonsi.devsimpletodoapp.RetrofitClient;
import com.autonsi.devsimpletodoapp.model.ToDoItem;
import com.autonsi.devsimpletodoapp.serviceinterface.ApiService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import java.util.List;

public class ToDoRepository {
    private ApiService apiService;
    MutableLiveData<List<ToDoItem>> todoList = new MutableLiveData<>();

    public ToDoRepository() {
        this.apiService = RetrofitClient.getApiService();
    }

    public MutableLiveData<List<ToDoItem>> getlit() {
        return todoList;
    }

    public MutableLiveData<List<ToDoItem>> getToDoList() {
        //MutableLiveData<List<ToDoItem>> data = new MutableLiveData<>();
        apiService.getToDoList().enqueue(new Callback<List<ToDoItem>>() {
            @Override
            public void onResponse(Call<List<ToDoItem>> call, Response<List<ToDoItem>> response) {
                if (response.isSuccessful()) {
                    todoList.setValue(response.body());
                }
            }

            @Override
            public void onFailure(Call<List<ToDoItem>> call, Throwable t) {
                Log.e("ToDoRepository", "Error fetching data", t);
            }
        });
        return todoList;
    }

    public void addToDoItem(ToDoItem newTask, Callback<ToDoItem> callback) {
        apiService.addToDoItem(newTask).enqueue(new Callback<ToDoItem>() {
            @Override
            public void onResponse(Call<ToDoItem> call, Response<ToDoItem> response) {
                if (response.isSuccessful()) {
                   response.body();
                   getToDoList();
                }
            }

            @Override
            public void onFailure(Call<ToDoItem> call, Throwable t) {
                Log.e("ToDoRepository", "Error fetching data", t);
            }
        });
    }

    public void updateToDoItem(int id, ToDoItem updatedTask, Callback<ToDoItem> callback) {
        apiService.updateToDoItem(id, updatedTask).enqueue(new Callback<ToDoItem>() {
            @Override
            public void onResponse(Call<ToDoItem> call, Response<ToDoItem> response) {
                if (response.isSuccessful()) {
                    response.body();
                    getToDoList();
                }
            }

            @Override
            public void onFailure(Call<ToDoItem> call, Throwable t) {
                Log.e("ToDoRepository", "Error fetching data", t);
            }
        });
    }

    public void deleteToDoItem(int id, Callback<Void> callback) {
        apiService.deleteToDoItem(id).enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    response.body();
                    getToDoList();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Log.e("ToDoRepository", "Error fetching data", t);
            }
        });
    }
}

